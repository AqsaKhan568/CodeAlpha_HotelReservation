package org.example.demo6;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Scene13 extends Application {

    private ObservableList<Guest> guestsData = FXCollections.observableArrayList(GuestManager.guests);

    @Override
    public void start(Stage stage) {

        TableView<Guest> table = new TableView<>(guestsData);
        table.setMinWidth(700);

        TableColumn<Guest, Integer> guestIdCol = new TableColumn<>("Guest ID");
        guestIdCol.setMinWidth(80);
        guestIdCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));

        TableColumn<Guest, String> guestNameCol = new TableColumn<>("Guest Name");
        guestNameCol.setMinWidth(80);
        guestNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Guest, String> emailCol = new TableColumn<>("Email");
        emailCol.setMinWidth(80);
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));

        TableColumn<Guest, String> phoneNumberCol = new TableColumn<>("Phone Number");
        phoneNumberCol.setMinWidth(80);
        phoneNumberCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));

        TableColumn<Guest, String> bookingIdCol = new TableColumn<>("Booking ID");
        bookingIdCol.setMinWidth(80);
        bookingIdCol.setCellValueFactory(new PropertyValueFactory<>("bookingID"));

        table.getColumns().addAll(guestIdCol, guestNameCol, emailCol, phoneNumberCol, bookingIdCol);
        Button backButton = new Button("Back");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        backButton.setStyle(buttonStyle);
        backButton.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox vBox = new VBox(10, table, backButton);
        vBox.setPrefWidth(500); // Ensure VBox width aligns with table width

        HBox hBox = new HBox(10,vBox);

        BorderPane root = new BorderPane();
        root.setCenter(hBox);

        Scene scene = new Scene(root, 1200, 600);
        stage.setTitle("Show Guests");
        stage.setScene(scene);
        stage.show();
    }

}