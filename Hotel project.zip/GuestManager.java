package org.example.demo6;
import java.io.*;
import java.util.ArrayList;

public class GuestManager {
    public static ArrayList<Guest> guests = new ArrayList<>();

    static {
        guests = FileUtil.loadGuests("C:\\demo6\\guests.dat");
    }

    public static void saveGuests() {
        FileUtil.saveGuests(guests, "C:\\demo6\\guests.dat");
    }
}

