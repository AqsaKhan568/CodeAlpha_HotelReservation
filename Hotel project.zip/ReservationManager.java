package org.example.demo6;
import java.io.*;
import java.util.ArrayList;

public class ReservationManager {
    public static ArrayList<Reservation> reservations = new ArrayList<>();
    public static ArrayList<Room> rooms = new ArrayList<>();
    public static ArrayList<Guest> guests = new ArrayList<>();

    static {
        reservations = FileUtil.loadReservations("C:\\demo6\\reservations.dat");
    }

    public static void saveReservations() {
        FileUtil.saveReservations(reservations, "C:\\demo6\\reservations.dat");
    }
}
