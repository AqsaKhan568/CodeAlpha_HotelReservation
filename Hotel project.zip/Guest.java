package org.example.demo6;
import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Guest implements Serializable{

    private static final long serialVersionUID = 7534769111326329986L;
    private int customerID;
    private String name;
    private String email;
    private String phoneNumber;
    private String bookingID;

    //constructor

    public Guest(int customerID, String name, String email, String phoneNumber, String bookingID) {
        this.customerID = customerID;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.bookingID = bookingID;
    }

    public Guest(String name) {
        this.name = name;
    }

    public Guest(int customerID) {
        this.customerID = customerID;
    }

    //getter/setter

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        if (customerID<=0) {
            System.out.println("invalid id. ");
            throw new IllegalArgumentException();
        };
        this.customerID = customerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getBookingID() {
        return bookingID;
    }

    public void setBookingID(String bookingID) {
        this.bookingID = bookingID;
    }


    public void printDetails() {
        System.out.println("Customer ID: " + customerID);
        System.out.println("Name: " + name);
        System.out.println("email: " + email);
        System.out.println("PHone Number: " + phoneNumber);
        System.out.println("Booking ID: " + bookingID);

    }

    public static void AddNewGuest(ArrayList<Guest> guests) {
        Scanner input = new Scanner(System.in);
        Scanner inputString = new Scanner(System.in);
        int ID =0;
        boolean isDuplicate;
        do {
            System.out.println("enter customer ID: ");
            try{
                ID = input.nextInt();
            }catch (InputMismatchException exp){
                System.out.println(exp.getMessage());
            }
            // check if customer id already exist
            isDuplicate = false;
            for (Guest guest : guests) {
                if (guest.getCustomerID() == ID) {
                    isDuplicate = true;
                    System.out.println("this ID " +ID+ " already exist enter new id.");
                    break;
                }
            }
        }while (isDuplicate);

        System.out.println("enter name: ");
        String name = inputString.nextLine();
        System.out.println("enter email: ");
        String email = inputString.nextLine();
        System.out.println("enter phone number:");
        String phoneNumber = inputString.nextLine();
        String bookingID;

        do {
            System.out.println("enter booking ID: ");
            bookingID = inputString.nextLine();
            // check if bookingID already exist
            isDuplicate= false;
            for (Guest guest : guests) {
                if (guest.getBookingID().equals(bookingID)) {
                    isDuplicate = true;
                    System.out.println("this booking ID " +bookingID+ " already exist enter new booking id.");
                    break;
                }
            }
        }while (isDuplicate);


        Guest guest = new Guest(ID, name, email, phoneNumber, bookingID);

        guests.add(guest);
        System.out.println("guest Added Successfully!");
        System.out.println();

    }


    public static void RemoveGuest(ArrayList<Guest> guests){
        Scanner input = new Scanner(System.in);
        int ID=0;
        boolean removed = false;
        do{
            System.out.println("Enter customer ID of the guest to remove: ");
            try{
                ID = input.nextInt();
            }catch (InputMismatchException exp){
                System.out.println(exp.getMessage());
            }

            for(int i = 0;i< guests.size(); i++) {
                if (guests.get(i).getCustomerID() == ID) {
                    guests.remove(i);
                    removed = true;
                    System.out.println("Guest with ID " + ID + " removed successfully.");
                    break;
                }
            }
            if(!removed){
                System.out.println("Guest with ID " +ID+ " not found.");
            }

        }while(!removed);

    }

    public static void ShowAllGuests(ArrayList<Guest> guests) {
        if(guests.isEmpty()){
            System.out.println(" no guest added yet.");
        }else {
            for (Guest guest : guests) {
                System.out.println("........................");
                guest.printDetails();
                System.out.println(".........................");
                System.out.println();
            }
        }
    }


}
