package org.example.demo6;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Reservation implements Serializable{

    private static final long serialVersionUID = 1L;

    private String reservationID;
    private Guest guest;
    private  Room room;
    private LocalDate checkInDate;
    private LocalDate CheckOutDate;


    //constructor

    public Reservation(String reservationID, Guest guest, Room room, LocalDate checkInDate,
                       LocalDate checkOutDate) {
        this.reservationID = reservationID;
        this.guest = guest;
        this.room = room;
        this.checkInDate = checkInDate;
        CheckOutDate = checkOutDate;
    }

    //getter/setter

    public String getReservationID() {
        return reservationID;
    }

    public void setReservationID(String reservationID) {
        this.reservationID = reservationID;
    }

    public Guest getGuest() {
        return guest;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return CheckOutDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        CheckOutDate = checkOutDate;
    }



    //methods

    public static void AddNewReservation(ArrayList<Reservation> reservations,
                                         ArrayList<Guest> guests, ArrayList<Room> rooms) {
        Scanner input = new Scanner(System.in);
        Scanner inputString = new Scanner(System.in);

        // display available rooms
        System.out.println("Available Rooms:");
        for (Room room : rooms) {
            if (!room.isReserved()) {
                System.out.println(room.getRoomNumber());
            }
        }

        // ask guest details
        System.out.println("Enter guest details...");
        System.out.println("Enter guest name:");
        String name = inputString.nextLine();
        System.out.println("Enter guest ID:");
        int ID = input.nextInt();

        // ask room selection
        System.out.print("Enter room number to reserve: ");
        int roomNumber = input.nextInt();

        // Find the room object from the list
        Room selectedRoom = null;
        for (Room room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                selectedRoom = room;
                break;
            }
        }

        // Check if the room is available
        if (selectedRoom == null || selectedRoom.isReserved()) {
            System.out.println("Invalid room selection or room is already reserved.");
            return;
        }

        // Find the guest object from the list
        Guest guest = null;
        for (Guest g : guests) {
            if (g.getName().equals(name) && g.getCustomerID() == ID) {
                guest = g;
                break;
            }
        }

        // Check if the guest exists
        if (guest == null) {
            System.out.println("Guest not found. Please add the guest first.");
            return;
        }

        // Asking reservation details
        String reservationID;
        boolean validReservationID;
        do {
            System.out.println("Enter reservation ID: ");
            reservationID = inputString.nextLine();
            validReservationID = true;

            // Check if reservation ID already exists
            for (Reservation reservation : reservations) {
                if (reservation.getReservationID().equals(reservationID)) {
                    System.out.println("Reservation ID already exists. Please enter a valid reservation ID.");
                    validReservationID = false;
                    break;
                }
            }
        } while (!validReservationID);

        System.out.print("Enter check-in date (yyyy-MM-dd): ");
        String checkInDateInput = input.next();
        LocalDate checkInDate = LocalDate.parse(checkInDateInput);

        System.out.print("Enter check-out date (yyyy-MM-dd): ");
        String checkOutDateInput = input.next();
        LocalDate checkOutDate = LocalDate.parse(checkOutDateInput);

        // Create the reservation object
        Reservation reservation = new Reservation(reservationID, guest, selectedRoom, checkInDate, checkOutDate);
        reservations.add(reservation);

        // Update room status
        selectedRoom.setReserved(true);

        // Confirmation message
        System.out.println("Reservation added successfully!");
    }

    public static void cancelBooking(ArrayList<Reservation> reservations) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the ID of the reservation to cancel: ");
        String reservationID = String.valueOf(input.nextInt());

        Reservation reservationToRemove = null;

        for (Reservation reservation : reservations) {
            if (reservation.getReservationID().equals(reservationID)) {
                reservationToRemove = reservation;
                break;
            }
        }
        if (reservationToRemove == null) {
            System.out.println("Reservation not found. Please enter a valid reservation ID.");
            return;
        }
        // Update room status
        reservationToRemove.getRoom().setReserved(false);

        reservations.remove(reservationToRemove);
        System.out.println("Reservation canceled successfully!");
    }


    public static void showAllReservations(ArrayList<Reservation> reservations) {
        if (reservations.isEmpty()) {
            System.out.println("No reservations added yet.");
        } else {
            for (Reservation reservation : reservations) {
                Room room = reservation.getRoom();
                if (room != null) {
                    System.out.println("Reservation ID: "+reservation.reservationID);
                    System.out.println("Room Number: " + room.getRoomNumber());
                    System.out.println("Guest Name: " + reservation.getGuest().getName());
                    System.out.println("Check-In Date: " + reservation.getCheckInDate());
                    System.out.println("Check-Out Date: " + reservation.getCheckOutDate());
                    System.out.println("-------------------------------");
                } else {
                    System.out.println("Invalid reservation: room is null.");
                }
            }
        }
    }
}

