package org.example.demo6;
import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Room  implements Serializable {


    private static final long serialVersionUID = 5421409042710381000L;
    private int roomNumber;

    private int floor;
    private String RoomType;

    private boolean reserved;


    //Constructor

    public Room(int roomNumber, int floor, String roomType, boolean availability) {
        this.roomNumber = roomNumber;
        this.floor = floor;
        RoomType = roomType;
        this.reserved = false; // By default, the room is not reserved when created
    }

    public Room(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public Room() {

    }


    //getter/setter

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public String getRoomType() {
        return RoomType;
    }

    public void setRoomType(String roomType) {
        RoomType = roomType;
    }



    public boolean isReserved() {
        return reserved;
    }

    public void setReserved(boolean reserved) {
        this.reserved = reserved;
    }

    //methods


    public void printDetails() {
        System.out.println("Room number: " + roomNumber);
        System.out.println("Floor: " + floor);
        System.out.println("Room Type: " + RoomType);
        System.out.println("Status: "+reserved);
    }



    public static void AddNewRoom(ArrayList<Room> rooms) {
        Scanner input = new Scanner(System.in);
        Scanner inputString = new Scanner(System.in);
        boolean roomExists;
        int roomNumber=0;
        do {
            roomExists=false;
            System.out.println("enter Room number.");
            try{
                roomNumber = input.nextInt();
            }catch(InputMismatchException exp){
                System.out.println(exp.getMessage());
            }

            // Check if room number already exists
            for (Room room : rooms) {
                if (room.getRoomNumber() == roomNumber) {
                    System.out.println("Room " + roomNumber + " is already added. Cannot add again.");
                    roomExists= true;
                    break;
                }
            }
            if (!roomExists) {
                int floor=0;
                do {
                    System.out.println("Enter floor (1-4):");
                    try{
                        floor = input.nextInt();
                    }catch (InputMismatchException exp){
                        System.out.println(exp.getMessage());
                    }

                    if (floor < 1 || floor > 4) {
                        System.out.println("Floor number must be between 1 and 4. Please enter a valid floor number.");
                    }
                } while (floor < 1 || floor > 4);

                System.out.println("enter Room type.");
                String type = inputString.nextLine();
                double price=0;

                Room room1 = new Room(roomNumber, floor, type, true);
                rooms.add(room1);
                System.out.println("Room Added Successfully.");

                //  FileUtil.saveRooms(rooms, "rooms.dat");
            }
        } while (roomExists);

    }


    public static boolean removeRoom(ArrayList<Room> rooms) {
        Scanner scanner = new Scanner(System.in);
        int roomToRemove=0;
        System.out.println("Enter Room number:");
        try{
            roomToRemove = scanner.nextInt();
        }catch (InputMismatchException exp){
            System.out.println(exp.getMessage());
        }
        for (Room room : rooms) {
            if (room.getRoomNumber() == roomToRemove) {
                rooms.remove(room);
                System.out.println("Room removed successfully.");

                //   FileUtil.saveRooms(rooms, "rooms.dat");
                return true;
            }
        }
        System.out.println("Room not found.");
        return false;



    }


    public static void ShowAllRooms(ArrayList<Room> rooms) {
        for (Object obj : rooms) {
            if (obj instanceof Room) {
                Room room = (Room) obj;
                System.out.println(room);
            } else {
                System.out.println("Unexpected object in rooms list: " + obj.getClass().getName());
            }
        }
    }


    @Override
    public String toString() {
        return "Room{" +
                "roomNumber=" + roomNumber +
                ", floor=" + floor +
                ", RoomType='" + RoomType + '\'' +
                ", reserved=" + reserved +
                '}';
    }
}



