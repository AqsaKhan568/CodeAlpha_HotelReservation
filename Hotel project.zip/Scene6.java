package org.example.demo6;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Scene6 extends Application {

    private ObservableList<Guest> guestsData = FXCollections.observableArrayList(GuestManager.guests);

    @Override
    public void start(Stage stage6) {
        Image image = new Image("file:C:\\Users\\LUME\\Pictures\\ee.jpg");
        ImageView imageView = new ImageView(image);
        Image image1 = new Image("file:C:\\Users\\LUME\\Pictures\\kk.jpg");
        ImageView imageView1 = new ImageView(image1);
        imageView1.setFitWidth(650);
        imageView1.setFitHeight(400);
        Label Label = new Label(" Remove Guest ");
        Label.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 40));
        Label.setTextFill(Color.BLACK);
        Label l = new Label(" Enter the following details:");
        l.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 20));
        l.setTextFill(Color.BLACK);
        Label l1 = new Label(" Customer ID: ");
        l1.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        l1.setTextFill(Color.BLACK);
        TextField t1 = new TextField();
        t1.setPromptText("Enter customer id");
        Label messageLabel = new Label();
        messageLabel.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        messageLabel.setTextFill(Color.GREEN);
        Button b1 = new Button("Remove Guest");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        b1.setStyle(buttonStyle);

        b1.setOnAction(e -> {
            String customerIdText = t1.getText().trim();
            if (customerIdText.isEmpty()) {
                messageLabel.setText("Please enter Customer ID to remove guest.");
                return;
            }

            int idToRemove;
            try {
                idToRemove = Integer.parseInt(customerIdText);
            } catch (NumberFormatException ex) {
                messageLabel.setText("Invalid Customer ID. Please enter a valid number.");
                return;
            }

            boolean guestRemoved = false;
            for (Guest guest : GuestManager.guests) {
                if (guest.getCustomerID() == idToRemove) {
                    GuestManager.guests.remove(guest);
                    guestsData.remove(guest); // Remove from ObservableList
                    guestRemoved = true;
                    GuestManager.saveGuests();
                    break;
                }
            }

            if (guestRemoved) {
                messageLabel.setText("Guest with ID " + idToRemove + " removed successfully.");
            } else {
                messageLabel.setText("Guest with ID " + idToRemove + " not found.");
            }
        });

        Button b2 = new Button("Back");
        b2.setStyle(buttonStyle);
        b2.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage6.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        GridPane Layout = new GridPane();
        Layout.add(l,0,0);
        Layout.add(l1, 0, 2);
        Layout.add(t1, 1, 2);
        Layout.add(b1, 1, 4);
        Layout.add(b2, 2, 4);
        Layout.add(messageLabel, 1, 7, 6, 1);
        Layout.setVgap(5);
        Layout.setHgap(5);
        Layout.setAlignment(Pos.CENTER_LEFT);
        Rectangle rectangle = new Rectangle(470, 400, Color.LIGHTBLUE);
        rectangle.setStroke(Color.BLACK);
        rectangle.setStrokeWidth(2);
        StackPane pane = new StackPane(imageView,imageView1, rectangle, Layout, Label);
        StackPane.setAlignment(rectangle, Pos.CENTER_LEFT);
        StackPane.setAlignment(Label, Pos.TOP_CENTER);
        StackPane.setAlignment(imageView1,Pos.CENTER_RIGHT);
        Scene scene6 = new Scene(pane, 1200, 600);
        stage6.setTitle("Remove Guest");
        stage6.setResizable(false);
        stage6.setScene(scene6);
        stage6.show();
    }

}