package org.example.demo6;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.VBox;
import java.util.ArrayList;


import java.io.IOException;


public class Scene5 extends Application {

    @Override
    public void start(Stage stage5) {
        Image image = new Image("file:C:\\Users\\LUME\\Pictures\\ee.jpg");
        ImageView imageView = new ImageView(image);
        Image image1 = new Image("file:C:\\Users\\LUME\\Pictures\\kk.jpg");
        ImageView imageView1 = new ImageView(image1);
        imageView1.setFitWidth(670);
        imageView1.setFitHeight(400);
        Label Label = new Label(" Add Guest ");
        Label.setFont(Font.font("Times new Roman",FontWeight.BOLD, FontPosture.REGULAR,50));
        Label.setTextFill(Color.BLACK);
        Label l = new Label(" Enter the following details:");
        l.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 20));
        l.setTextFill(Color.BLACK);
        Label l1 = new Label(" Customer ID: ");
        l1.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        l1.setTextFill(Color.BLACK);
        TextField t1 = new TextField();
        t1.setPromptText("Enter customer id");
        Label l2 = new Label(" Name: ");
        l2.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        l2.setTextFill(Color.BLACK);
        TextField t2 = new TextField();
        t2.setPromptText("Enter Name");
        Label l3 = new Label(" Email: ");
        l3.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        l3.setTextFill(Color.BLACK);
        TextField t3 = new TextField();
        t3.setPromptText("Enter Email");
        Label l4 = new Label(" Phone no: ");
        l4.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        l4.setTextFill(Color.BLACK);
        TextField t4 = new TextField();
        t4.setPromptText("Enter Phone no");
        Label l5 = new Label(" Booking ID: ");
        l5.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        l5.setTextFill(Color.BLACK);
        TextField t5 = new TextField();
        t5.setPromptText("Enter Booking id");
        Label messageLabel = new Label();
        messageLabel.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        messageLabel.setTextFill(Color.GREEN);
        Button b1 = new Button("Add Guest");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        b1.setStyle(buttonStyle);
        // Event handler for the Add Guest button
        b1.setOnAction(e -> {
            String customerIDText = t1.getText();
            String name = t2.getText();
            String email = t3.getText();
            String phoneNumber = t4.getText();
            String bookingID = t5.getText();

            if (customerIDText.isEmpty() || name.isEmpty() || email.isEmpty() || phoneNumber.isEmpty() || bookingID.isEmpty()) {
                messageLabel.setTextFill(Color.RED);
                messageLabel.setText("Please fill in all the fields.");
            } else {
                try {
                    int customerID = Integer.parseInt(customerIDText);

                    // Check for duplicate customerID and bookingID
                    boolean isDuplicateID = GuestManager.guests.stream().anyMatch(guest -> guest.getCustomerID() == customerID);
                    boolean isDuplicateBookingID = GuestManager.guests.stream().anyMatch(guest -> guest.getBookingID().equals(bookingID));

                    if (isDuplicateID) {
                        messageLabel.setTextFill(Color.RED);
                        messageLabel.setText("Customer ID already exists.");
                    } else if (isDuplicateBookingID) {
                        messageLabel.setTextFill(Color.RED);
                        messageLabel.setText("Booking ID already exists.");
                    } else {
                        Guest guest = new Guest(customerID, name, email, phoneNumber, bookingID);
                        GuestManager.guests.add(guest);
                        ///////////////////////////////
                        FileUtil.saveGuests(GuestManager.guests, "C:\\demo6\\guests.dat");
                        messageLabel.setTextFill(Color.GREEN);
                        messageLabel.setText("Guest added successfully.");
                    }
                } catch (NumberFormatException ex) {
                    messageLabel.setTextFill(Color.RED);
                    messageLabel.setText("Invalid input for Customer ID. Please enter a valid number.");
                }
            }
        });


        Button b2 = new Button(" Back");
        b2.setStyle(buttonStyle);
        // Event handler for the back button
        b2.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage5.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        GridPane Layout = new GridPane();
        Layout.add(l,0,0);
        Layout.add(l1, 0, 2);
        Layout.add(t1, 1, 2);
        Layout.add(l2, 0, 3);
        Layout.add(t2, 1, 3);
        Layout.add(l3, 0, 4);
        Layout.add(t3, 1, 4);
        Layout.add(l4, 0, 5);
        Layout.add(t4, 1, 5);
        Layout.add(l5,0,6);
        Layout.add(t5,1,6);
        Layout.add(b1,1,7);
        Layout.add(b2,2,7);
        Layout.add(messageLabel, 1, 8, 2, 1);
        Layout.setVgap(5);
        Layout.setHgap(5);
        Layout.setAlignment(Pos.CENTER_LEFT);
        Rectangle rectangle = new Rectangle(470, 400, Color.LIGHTBLUE);
        rectangle.setStroke(Color.BLACK);
        rectangle.setStrokeWidth(2);
        StackPane pane = new StackPane(imageView,imageView1,rectangle,Layout,Label);
        StackPane.setAlignment(rectangle,Pos.CENTER_LEFT);
        StackPane.setAlignment(Label,Pos.TOP_CENTER);
        StackPane.setAlignment(imageView1,Pos.CENTER_RIGHT);
        Scene scene5 = new Scene(pane, 1200, 600);
        stage5.setTitle("Add guest");
        stage5.setScene(scene5);
        stage5.show();



    }
}