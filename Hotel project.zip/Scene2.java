package org.example.demo6;

import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.VBox;


import java.io.IOException;


public class Scene2 extends Application {

    @Override
    public void start(Stage stage2) throws IOException {
        Image image = new Image("file:C:\\Users\\LUME\\Pictures\\ee.jpg");
        ImageView imageView = new ImageView(image);
        //Image image1 = new Image("file:C:\\Users\\LUME\\Pictures\\Rec.jpg");
        //ImageView imageView1 = new ImageView(image1);
        //imageView1.setFitWidth(350);
        //imageView1.setFitHeight(350);
        Label l1 = new Label("Welcome");
        l1.setFont(Font.font("Times new Roman",FontWeight.BOLD, FontPosture.REGULAR,50));
        l1.setTextFill(Color.BLACK);
        Label l2 = new Label(" Room Details: ");
        l2.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        l2.setTextFill(Color.BLACK);
        Label l3 = new Label(" Guest Details: ");
        l3.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        l3.setTextFill(Color.BLACK);
        Label l4 = new Label(" Reservation: ");
        l4.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        l4.setTextFill(Color.BLACK);
        Button b1 = new Button("Add");
        Button b2 = new Button("Remove");
        Button b3 = new Button("All");
        Button b4 = new Button("Add");
        Button b5 = new Button("Remove");
        Button b6 = new Button("All");
        Button b7 = new Button("Register");
        Button b8 = new Button("Cancel Booking");
        Button b9 = new Button("All");
        Button b13 = new Button("Exit");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        b1.setStyle(buttonStyle);
        b2.setStyle(buttonStyle);
        b3.setStyle(buttonStyle);
        b4.setStyle(buttonStyle);
        b5.setStyle(buttonStyle);
        b6.setStyle(buttonStyle);
        b7.setStyle(buttonStyle);
        b8.setStyle(buttonStyle);
        b9.setStyle(buttonStyle);
        b13.setStyle(buttonStyle);
        // Event handler for the exit button
        b13.setOnAction(e -> {
            Scene1 scene1 = new Scene1();
            Stage stage1 = new Stage();
            try {
                scene1.start(stage1);
                stage2.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the Add room button
        b1.setOnAction(e -> {
            Scene3 scene3 = new Scene3();
            Stage stage3 = new Stage();
            try {
                scene3.start(stage3);
                stage2.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the Remove room button
        b2.setOnAction(e -> {
            Scene4 scene4 = new Scene4();
            Stage stage4 = new Stage();
            try {
                scene4.start(stage4);
                stage2.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the Show all room button
        b3.setOnAction(e -> {
            ShowRoom showRoom = new ShowRoom();
            Stage stage12 = new Stage();
            try {
                showRoom.start(stage12);
                stage2.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the Add guest button
        b4.setOnAction(e -> {
            Scene5 scene5 = new Scene5();
            Stage stage5 = new Stage();
            try {
                scene5.start(stage5);
                stage2.close(); // Close the current stage (Scene2)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the Remove guest button
        b5.setOnAction(e -> {
            Scene6 scene6 = new Scene6();
            Stage stage6 = new Stage();
            try {
                scene6.start(stage6);
                stage2.close(); // Close the current stage (Scene2)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the show all guest button
        b6.setOnAction(e -> {
            Scene13 scene13 = new Scene13();
            Stage stage13 = new Stage();
            try {
                scene13.start(stage13);
                stage2.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the register reservation button
        b7.setOnAction(e -> {
            Scene7 scene7 = new Scene7();
            Stage stage7 = new Stage();
            try {
                scene7.start(stage7);
                stage2.close(); // Close the current stage (Scene2)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the cancel reservation button
        b8.setOnAction(e -> {
            Scene8 scene8 = new Scene8();
            Stage stage8 = new Stage();
            try {
                scene8.start(stage8);
                stage2.close(); // Close the current stage (Scene2)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Event handler for the show all reservation button
        b9.setOnAction(e -> {
            Scene14 scene14 = new Scene14();
            Stage stage14 = new Stage();
            try {
                scene14.start(stage14);
                stage2.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        GridPane Layout = new GridPane();
        Layout.add(l2,0,0);
        Layout.add(l3,0,2);
        Layout.add(l4,0,4);
        Layout.add(b1,1,1);
        Layout.add(b2,2,1);
        Layout.add(b3,3,1);
        Layout.add(b4,1,3);
        Layout.add(b5,2,3);
        Layout.add(b6,3,3);
        Layout.add(b7,1,5);
        Layout.add(b8,2,5);
        Layout.add(b9,3,5);
        Layout.add(b13,4,9);
        Layout.setHgap(5);
        Layout.setVgap(5);
        Layout.setAlignment(Pos.CENTER);
        Rectangle rectangle = new Rectangle(470, 320, Color.LIGHTBLUE);
        rectangle.setStroke(Color.BLACK);
        rectangle.setStrokeWidth(2);
        StackPane pane = new StackPane(imageView,rectangle,Layout,l1);
        StackPane.setAlignment(rectangle,Pos.CENTER);
        StackPane.setAlignment(l1,Pos.TOP_CENTER);
        Scene scene2 = new Scene(pane, 1200, 600);
        stage2.setTitle("welcome");
        //stage2.setResizable(false);
        stage2.setScene(scene2);
        stage2.show();
    }
}
