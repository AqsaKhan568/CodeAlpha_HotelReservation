package org.example.demo6;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.ByteArrayInputStream;

public class Scene4 extends Application {

    @Override
    public void start(Stage stage4) {
        Image image = new Image("file:C:\\Users\\LUME\\Pictures\\ee.jpg");
        ImageView imageView = new ImageView(image);
        Image image1 = new Image("file:C:\\Users\\LUME\\Pictures\\GH.jpg");
        ImageView imageView1 = new ImageView(image1);
        imageView1.setFitWidth(680);
        imageView1.setFitHeight(400);
        Label Label = new Label(" Remove Room ");
        Label.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 40));
        Label.setTextFill(Color.BLACK);
        Label l = new Label(" Enter the following details:");
        l.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 20));
        l.setTextFill(Color.BLACK);
        Label l1 = new Label(" Room no: ");
        l1.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        l1.setTextFill(Color.BLACK);
        TextField t1 = new TextField();
        t1.setPromptText("Enter room no");
        Label l2 = new Label(" Floor: ");
        l2.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        l2.setTextFill(Color.BLACK);
        ComboBox<String> comboBox = new ComboBox<>(FXCollections.observableArrayList("1st floor", "2nd floor", "3rd floor", "4th floor"));
        comboBox.setPromptText(" Select floor");
        Label l3 = new Label(" Room type: ");
        l3.setTextFill(Color.BLACK);
        l3.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        CheckBox cb1 = new CheckBox("Single");
        CheckBox cb2 = new CheckBox("Double");
        cb1.setOnAction(e -> {
            if (cb1.isSelected()) {
                cb2.setSelected(false);
            }
        });
        cb2.setOnAction(e -> {
            if (cb2.isSelected()) {
                cb1.setSelected(false);
            }
        });
        Label messageLabel = new Label();
        messageLabel.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        messageLabel.setTextFill(Color.GREEN);
        Button b1 = new Button("Remove Room");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        b1.setStyle(buttonStyle);

        b1.setOnAction(e -> {
            try {
                int roomNumber = Integer.parseInt(t1.getText());
                boolean roomRemoved = false;
                for (Room room : RoomManager.rooms) {
                    if (room.getRoomNumber() == roomNumber) {
                        RoomManager.rooms.remove(room);
                        roomRemoved = true;
                        RoomManager.saveRooms();
                        break;
                    }
                }
                if (roomRemoved) {
                    messageLabel.setTextFill(Color.GREEN);
                    messageLabel.setText("Room removed successfully.");
                } else {
                    messageLabel.setTextFill(Color.RED);
                    messageLabel.setText("Room not found.");
                }
            } catch (NumberFormatException ex) {
                messageLabel.setTextFill(Color.RED);
                messageLabel.setText("Please enter a valid room number.");
            }
        });

        Button b2 = new Button(" Back");
        b2.setStyle(buttonStyle);
        b2.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage4.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        GridPane Layout = new GridPane();
        Layout.add(l,0,0);
        Layout.add(l1, 0, 2);
        Layout.add(t1, 1, 2);
        Layout.add(l2, 0, 3);
        Layout.add(comboBox, 1, 3);
        Layout.add(l3, 0, 4);
        Layout.add(cb1, 1, 4);
        Layout.add(cb2, 2, 4);
        Layout.add(b1, 1, 7);
        Layout.add(b2, 2, 7);
        Layout.add(messageLabel, 1, 8, 5, 1);
        Layout.setVgap(5);
        Layout.setHgap(5);
        Layout.setAlignment(Pos.CENTER_LEFT);
        Rectangle rectangle = new Rectangle(470, 400, Color.LIGHTBLUE);
        rectangle.setStroke(Color.BLACK);
        rectangle.setStrokeWidth(2);
        StackPane pane = new StackPane(imageView,imageView1, rectangle, Layout, Label);
        StackPane.setAlignment(rectangle, Pos.CENTER_LEFT);
        StackPane.setAlignment(Label, Pos.TOP_CENTER);
        StackPane.setAlignment(imageView1,Pos.CENTER_RIGHT);
        Scene scene4 = new Scene(pane, 1200, 600);
        stage4.setTitle("Remove Room");
        //stage4.setResizable(false);
        stage4.setScene(scene4);
        stage4.show();
    }


}
