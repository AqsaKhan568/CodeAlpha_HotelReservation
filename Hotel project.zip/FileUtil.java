package org.example.demo6;
import java.io.*;
import java.util.ArrayList;

public class FileUtil {

    public static void saveRooms(ArrayList<Room> rooms, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(rooms);
            System.out.println("Rooms saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Room> loadRooms(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            System.out.println("File " + fileName + " does not exist. Returning an empty list.");
            return new ArrayList<>();
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            ArrayList<Room> rooms = (ArrayList<Room>) ois.readObject();
            System.out.println("Rooms loaded successfully. Total rooms: " + rooms.size());
            return rooms;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }


    // Similar methods for Guest
    public static void saveGuests(ArrayList<Guest> guests, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(guests);
            System.out.println("Guests saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Guest> loadGuests(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            System.out.println("File " + fileName + " does not exist. Returning an empty list.");
            return new ArrayList<>();
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            ArrayList<Guest> guests = (ArrayList<Guest>) ois.readObject();
            System.out.println("Guests loaded successfully. Total guests: " + guests.size());
            return guests;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // Similar methods for Reservation
  /*  public static void saveReservations(ArrayList<Reservation> reservations, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(reservations);
            System.out.println("Reservations saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Reservation> loadReservations(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            System.out.println("File " + fileName + " does not exist. Returning an empty list.");
            return new ArrayList<>();
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            ArrayList<Reservation> reservations = (ArrayList<Reservation>) ois.readObject();
            System.out.println("Reservations loaded successfully. Total reservations: " + reservations.size());
            return reservations;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }*/

    public static void saveReservations(ArrayList<Reservation> reservations, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(reservations);
            System.out.println("Reservations saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Reservation> loadReservations(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            System.out.println("File " + fileName + " does not exist. Returning an empty list.");
            return new ArrayList<>();
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            ArrayList<Reservation> reservations = (ArrayList<Reservation>) ois.readObject();
            System.out.println("Reservations loaded successfully. Total reservations: " + reservations.size());
            return reservations;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}

