package org.example.demo6;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.VBox;
import javafx.beans.binding.Bindings;


import java.io.IOException;

public class Scene1 extends Application {
    @Override
    public void start(Stage stage1) throws IOException {
        Image image = new Image("file:C:\\Users\\LUME\\Pictures\\ee.jpg");
        ImageView imageView = new ImageView(image);
        Label label = new Label("Hotel management system");
        label.setFont(Font.font("Times new Roman",FontWeight.BOLD, FontPosture.REGULAR,50));
        label.setTextFill(Color.BLACK);
        Label l1 = new Label("Username:");
        l1.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        TextField t1 = new TextField();
        t1.setPromptText("Enter username");
        Label l2 = new Label("Password: ");
        l2.setFont(Font.font("Times new Roman",FontWeight.SEMI_BOLD, FontPosture.REGULAR,20));
        TextField t2 = new TextField();
        t2.setPromptText("Enter password");
        Label errorLabel = new Label();
        errorLabel.setTextFill(Color.RED);
        errorLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 12));
        Button b1 = new Button("Login");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        b1.setStyle(buttonStyle);
        // Event handler for the login button
        b1.setOnAction(e -> {
            if (t1.getText().trim().isEmpty() && t2.getText().trim().isEmpty()) {
                errorLabel.setText("Please enter username and password");
            } else if (t1.getText().trim().isEmpty()) {
                errorLabel.setText("Please enter username");
            } else if (t2.getText().trim().isEmpty()) {
                errorLabel.setText("Please enter password");
            } else {

                Scene2 scene2 = new Scene2();
                Stage stage2 = new Stage();
                try {
                    scene2.start(stage2);
                    stage1.close(); // Close the current stage (Scene1)
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        });
        Button b2 = new Button("Exit");
        b2.setStyle(buttonStyle);
        b2.setOnAction(e -> {
            try {
                stage1.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        GridPane Layout = new GridPane();
        Layout.add(l1, 0, 0);
        Layout.add(t1, 1, 0);
        Layout.add(l2, 0, 1);
        Layout.add(t2, 1, 1);
        Layout.add(b1, 3, 4);
        Layout.add(b2,4,4);
        Layout.add(errorLabel, 1, 3, 2, 1);  // Span the errorLabel across 2 columns
        Layout.setVgap(5);
        Layout.setHgap(5);
        Layout.setAlignment(Pos.CENTER);
        Rectangle rectangle = new Rectangle(390, 200, Color.LIGHTBLUE);
        rectangle.setStroke(Color.BLACK);
        rectangle.setStrokeWidth(2);
        StackPane pane = new StackPane(imageView,rectangle,Layout,label);
        StackPane.setAlignment(rectangle,Pos.CENTER);
        StackPane.setAlignment(label,Pos.TOP_CENTER);
        Scene scene1 = new Scene(pane, 1200, 600);
        stage1.setTitle("Login");
        //stage1.setResizable(false);
        stage1.setScene(scene1);
        stage1.show();


    }

}