package org.example.demo6;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

public class Scene8 extends Application {

    private ObservableList<Reservation> ReservationData = FXCollections.observableArrayList(ReservationManager.reservations);
    @Override
    public void start(Stage stage8) throws IOException {
        Image image = new Image("file:C:\\Users\\LUME\\Pictures\\ee.jpg");
        ImageView imageView = new ImageView(image);
        imageView.fitHeightProperty().bind(stage8.heightProperty());
        imageView.fitWidthProperty().bind(stage8.widthProperty());
        Image image1 = new Image("file:C:\\Users\\LUME\\Pictures\\Reg.jpg");
        ImageView imageView1 = new ImageView(image1);
        imageView1.setFitWidth(700);
        imageView1.setFitHeight(400);
        Label l = new Label(" Enter the following details:");
        l.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 20));
        l.setTextFill(Color.BLACK);
        Label Label = new Label(" Remove Reservation ");
        Label.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 50));
        Label.setTextFill(Color.BLACK);

        Label l1 = new Label("Guest ID: ");
        TextField tf1 = new TextField();
        tf1.setPromptText("Enter guest ID ");
        Label l2 = new Label("Reservation ID: ");
        TextField tf2 = new TextField();
        tf2.setPromptText("Enter reservation ID ");
        Label l3 = new Label("Room Number: ");
        ComboBox<Integer> CB1 = new ComboBox<>();
        CB1.getItems().addAll(1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,13,14,15,16,17,18,19,20);
        CB1.setPromptText("Select room number");
        Label l4 = new Label("Room Type: ");
        RadioButton rb1 = new RadioButton("Single");
        RadioButton rb2 = new RadioButton("Double");
        ToggleGroup tg1 = new ToggleGroup();
        rb1.setToggleGroup(tg1);
        rb2.setToggleGroup(tg1);

        l1.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l2.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l3.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l4.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        rb1.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 12px; -fx-font-weight: bold;");
        rb2.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 12px; -fx-font-weight: bold;");

        // Buttons
        Button cancelBooking = new Button("Cancel Booking");
        Button b2 = new Button("Back");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        cancelBooking.setStyle(buttonStyle);
        b2.setStyle(buttonStyle);

        // Event handler for the back button
        b2.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage8.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // Event handling for cancel booking button
        cancelBooking.setOnAction(handler -> handleCancelBooking(tf2));

        GridPane layout = new GridPane();
        layout.add(l,0,0);
        layout.add(l1, 0, 2);
        layout.add(tf1, 1, 2);
        layout.add(l2, 0, 3);
        layout.add(tf2, 1, 3);
        layout.add(l3, 0, 4);
        layout.add(CB1, 1, 4);
        layout.add(l4, 0, 5);
        layout.add(rb1, 1, 5);
        layout.add(rb2, 2, 5);
        layout.add(cancelBooking, 0, 9);
        layout.add(b2, 1, 9);

        layout.setAlignment(Pos.CENTER_LEFT);
        layout.setTranslateX(20);
        layout.setVgap(6);
        layout.setHgap(6);
        Rectangle rectangle = new Rectangle(480, 400, Color.LIGHTBLUE);
        rectangle.setStroke(Color.BLACK);
        rectangle.setStrokeWidth(2);
        VBox vBox1 = new VBox(rectangle);
        vBox1.setAlignment(Pos.CENTER_LEFT);
       // vBox1.setTranslateX(15);

        StackPane stackPane = new StackPane(imageView,imageView1, vBox1, layout,Label);
        Scene scene = new Scene(stackPane, 1200, 600);
        StackPane.setAlignment(Label, Pos.TOP_CENTER);
        StackPane.setAlignment(imageView1,Pos.CENTER_RIGHT);

        stage8.setTitle("remove reservation");
        stage8.setScene(scene);
        stage8.show();
    }

    private void handleCancelBooking(TextField tf2) {
        String reservationID = tf2.getText();

        if (reservationID.isEmpty()) {
            showAlert("Error", "Please enter the reservation ID.");
            return;
        }

        Reservation reservationToRemove = null;
        for (Reservation reservation : ReservationManager.reservations) {
            if (reservation.getReservationID().equals(reservationID)) {
                ReservationManager.reservations.remove(reservation);
                ReservationData.remove(reservation);
                reservationToRemove = reservation;
                ReservationManager.saveReservations();
                break;
            }
        }


        if (reservationToRemove == null) {
            showAlert("Error", "Reservation not found. Please enter a valid reservation ID.");
            return;
        }

        // Update room status
        reservationToRemove.getRoom().setReserved(false);

        ReservationManager.reservations.remove(reservationToRemove);
        showAlert("Success", "Reservation canceled successfully!");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

