package org.example.demo6;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class Scene7 extends Application {

    @Override
    public void start(Stage stage7) throws IOException {
        GuestManager guestManager = new GuestManager();
        RoomManager roomManager = new RoomManager();

        Image image = new Image("file:C:\\Users\\LUME\\Pictures\\ee.jpg");
        ImageView imageView = new ImageView(image);
        imageView.fitHeightProperty().bind(stage7.heightProperty());
        imageView.fitWidthProperty().bind(stage7.widthProperty());
        Image image1 = new Image("file:C:\\Users\\LUME\\Pictures\\Reg.jpg");
        ImageView imageView1 = new ImageView(image1);
        imageView1.setFitWidth(700);
        imageView1.setFitHeight(400);
        Label l = new Label(" Enter the following details:");
        l.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 20));
        l.setTextFill(Color.BLACK);
        Label Label = new Label(" Add Reservation ");
        Label.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 50));
        Label.setTextFill(Color.BLACK);

        Label l1 = new Label("Guest ID: ");
        TextField tf1 = new TextField();
        tf1.setPromptText("Enter guest ID ");
        Label l2 = new Label("Reservation ID: ");
        TextField tf2 = new TextField();
        tf2.setPromptText("Enter reservation ID ");
        Label l3 = new Label("Room Number: ");
        ComboBox<Integer> CB1 = new ComboBox<>();
        CB1.getItems().addAll(1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,13,14,15,16,17,18,19,20);
        CB1.setPromptText("Select room number");
        Label l4 = new Label("Room Type: ");
        RadioButton rb1 = new RadioButton("Single");
        RadioButton rb2 = new RadioButton("Double");
        ToggleGroup tg1 = new ToggleGroup();
        rb1.setToggleGroup(tg1);
        rb2.setToggleGroup(tg1);
        Label l5 = new Label("Days of stay: ");
        TextField tf5 = new TextField();
        tf5.setPromptText("Enter days of stay ");
        Label l6 = new Label("Price per Night: ");
        TextField tf6 = new TextField();
        tf6.setPromptText("Enter price ");
        Label l7 = new Label("Check In date: ");
        TextField tf7 = new TextField();
        tf7.setPromptText("YYYY-MM-DD");
        Label l8 = new Label("Check out date: ");
        TextField tf8 = new TextField();
        tf8.setPromptText("YYYY-MM-DD");
        l1.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l2.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l3.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l4.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l5.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l6.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l7.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        l8.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        rb1.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 12px; -fx-font-weight: bold;");
        rb2.setStyle("-fx-text-fill: Black; -fx-font-family: 'Times New Roman'; -fx-font-size: 12px; -fx-font-weight: bold;");

        // Buttons
        Button payment = new Button("Payment>>");
        Button register = new Button("Register");
        Button b2 = new Button("Back");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        payment.setStyle(buttonStyle);
        register.setStyle(buttonStyle);
        b2.setStyle(buttonStyle);

        // Event handler for the back button
        b2.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage7.close(); // Close the current stage (Scene1)
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        GridPane layout = new GridPane();
        layout.add(l,0,0);
        layout.add(l1, 0, 2);
        layout.add(tf1, 1, 2);
        layout.add(l2, 0, 3);
        layout.add(tf2, 1, 3);
        layout.add(l3, 0, 4);
        layout.add(CB1, 1, 4);
        layout.add(l4, 0, 5);
        layout.add(rb1, 1, 5);
        layout.add(rb2, 2, 5);
        layout.add(l5, 0, 6);
        layout.add(tf5, 1, 6);
        layout.add(l6, 0, 7);
        layout.add(tf6, 1, 7);
        layout.add(l7, 0, 8);
        layout.add(tf7, 1, 8);
        layout.add(l8, 0, 9);
        layout.add(tf8, 1, 9);
        layout.add(payment, 0, 10);
        layout.add(register, 0, 11);
        layout.add(b2, 1, 11);

        layout.setAlignment(Pos.CENTER_LEFT);
        layout.setTranslateX(20);
        layout.setVgap(6);
        layout.setHgap(6);

        // Scene 2
        Image image2 = new Image("file:C:\\Users\\Hp\\Downloads\\register 123.jpeg");
        ImageView imageView2 = new ImageView(image2);
        imageView2.fitHeightProperty().bind(stage7.heightProperty());
        imageView2.fitWidthProperty().bind(stage7.widthProperty());
        Rectangle rectangle = new Rectangle(480, 400, Color.LIGHTBLUE);
        rectangle.setStroke(Color.BLACK);
        rectangle.setStrokeWidth(2);
        VBox vBox1 = new VBox(rectangle);
        vBox1.setAlignment(Pos.CENTER_LEFT);
        //vBox1.setTranslateX(15);

        Rectangle rectangle2 = new Rectangle(500, 500);
        rectangle2.setFill(Color.BLACK);
        VBox vBox2 = new VBox(rectangle2);
        vBox2.setAlignment(Pos.CENTER);
        vBox2.setTranslateX(15);

        GridPane layout2 = new GridPane();
        Label label1 = new Label();
        Label label2 = new Label();
        Label label3 = new Label();

        Button payNow = new Button("Pay Now");
        Button Close = new Button("Close");
        String buttonStyle2 = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        payNow.setStyle(buttonStyle2);
        Close.setStyle(buttonStyle2);

        layout2.add(label1, 0, 0);
        layout2.add(label2, 0, 1);
        layout2.add(label3, 0, 2);
        layout2.add(payNow, 0, 3);
        layout2.add(Close, 1, 3);
        layout2.setAlignment(Pos.CENTER);
        layout2.setVgap(6);
        layout2.setHgap(6);

        label1.setStyle("-fx-text-fill: White; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        label2.setStyle("-fx-text-fill: White; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");
        label3.setStyle("-fx-text-fill: White; -fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;");

        StackPane stackPane2 = new StackPane(imageView2, vBox2, layout2);
        StackPane stackPane = new StackPane(imageView,imageView1, vBox1, layout,Label);
        StackPane.setAlignment(imageView1,Pos.CENTER_RIGHT);
        StackPane.setAlignment(Label, Pos.TOP_CENTER);
        Scene scene = new Scene(stackPane, 1200, 600);
        Scene scene1 = new Scene(stackPane2, 500, 500);

        // Event Handling
        payment.setOnAction(handler -> {
            try {
                int days = Integer.parseInt(tf5.getText());
                double price = Double.parseDouble(tf6.getText());
                double Payment = days * price;
                label1.setText("Days of stay:  " + days);
                label2.setText("Price:  " + price);
                label3.setText("Total Bill: " + Payment);
                stage7.setScene(scene1);
            } catch (NumberFormatException e) {
                showAlert("Error", "Please enter valid numeric values for days of stay and price.");
            }
        });
        Close.setOnAction(e -> stage7.setScene(scene));
        //Event handling on register button
        register.setOnAction(handler -> handleRegister(tf1, tf2, CB1, tf7, tf8, tf5, tf6));

        stage7.setTitle("Hello!");
        stage7.setScene(scene);
        stage7.show();
    }

    private void handleRegister(TextField tf1, TextField tf2, ComboBox<Integer> CB1, TextField tf7, TextField tf8, TextField tf5, TextField tf6) {
        String guestID = tf1.getText();
        String reservationID = tf2.getText();
        Integer roomNumber = CB1.getValue();
        String checkInDate = tf7.getText();
        String checkOutDate = tf8.getText();
        String daysOfStay = tf5.getText();
        String pricePerNight = tf6.getText();

        if (guestID.isEmpty() || reservationID.isEmpty() || roomNumber == null || checkInDate.isEmpty() || checkOutDate.isEmpty() || daysOfStay.isEmpty() || pricePerNight.isEmpty()) {
            showAlert("Error", "Please fill all fields before registering.");
            return;
        }

        Guest guest = GuestManager.guests.stream().filter(g -> String.valueOf(g.getCustomerID()).equals(guestID)).findFirst().orElse(null);
        if (guest == null) {
            showAlert("Error", "Guest not found.");
            return;
        }

        Room room = RoomManager.rooms.stream().filter(r -> r.getRoomNumber() == roomNumber && !r.isReserved()).findFirst().orElse(null);
        if (room == null) {
            showAlert("Error", "Room not available.");
            return;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        try {
            LocalDate checkIn = LocalDate.parse(checkInDate, formatter);
            LocalDate checkOut = LocalDate.parse(checkOutDate, formatter);
            Reservation reservation = new Reservation(reservationID, guest, room, checkIn, checkOut);
            ReservationManager.reservations.add(reservation);
            room.setReserved(true);
            FileUtil.saveReservations(ReservationManager.reservations, "C:\\demo6\\reservations.dat");
            showAlert("Success", "Reservation added successfully!");
        } catch (DateTimeParseException e) {
            showAlert("Error", "Please enter valid dates in the format YYYY-MM-DD.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }



}