package org.example.demo6;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.ArrayList;

public class Scene3 extends Application {

    @Override
    public void start(Stage stage3) {
        Image image = new Image("file:C:\\Users\\LUME\\Pictures\\ee.jpg");
        ImageView imageView = new ImageView(image);
        Image image1 = new Image("file:C:\\Users\\LUME\\Pictures\\GH.jpg");
        ImageView imageView1 = new ImageView(image1);
        imageView1.setFitWidth(700);
        imageView1.setFitHeight(400);
        Label l1 = new Label(" Enter the following details:");
        l1.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 20));
        l1.setTextFill(Color.BLACK);
        Label Label = new Label(" Add Room ");
        Label.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 50));
        Label.setTextFill(Color.BLACK);
        Label l2 = new Label(" Room no: ");
        l2.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        l2.setTextFill(Color.BLACK);
        TextField t1 = new TextField();
        t1.setPromptText("Enter room no");
        Label l3 = new Label(" Floor: ");
        l3.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        l3.setTextFill(Color.BLACK);
        ComboBox<String> comboBox = new ComboBox<>(FXCollections.observableArrayList("1st floor", "2nd floor", "3rd floor", "4th floor"));
        comboBox.setPromptText(" Select floor");
        Label l4 = new Label(" Room type: ");
        l4.setTextFill(Color.BLACK);
        l4.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        CheckBox cb1 = new CheckBox("Single");
        CheckBox cb2 = new CheckBox("Double");

        // Ensure only one checkbox can be selected at a time
        cb1.setOnAction(e -> {
            if (cb1.isSelected()) {
                cb2.setSelected(false);
            }
        });
        cb2.setOnAction(e -> {
            if (cb2.isSelected()) {
                cb1.setSelected(false);
            }
        });

        Label messageLabel = new Label();
        messageLabel.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 20));
        messageLabel.setTextFill(Color.GREEN);

        Button b1 = new Button("Add Room");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        b1.setStyle(buttonStyle);

        b1.setOnAction(e -> {
            try {
                int roomNumber = Integer.parseInt(t1.getText());
                String selectedFloor = comboBox.getValue();
                if (selectedFloor == null) {
                    messageLabel.setTextFill(Color.RED);
                    messageLabel.setText("Please select a floor.");
                    return;
                }
                int floor = comboBox.getSelectionModel().getSelectedIndex() + 1;
                String roomType = cb1.isSelected() ? "Single" : (cb2.isSelected() ? "Double" : "");

                if (roomType.isEmpty()) {
                    messageLabel.setTextFill(Color.RED);
                    messageLabel.setText("Please select a room type.");
                    return;
                }

                // Check if the room number already exists
                boolean roomExists = false;
                for (Room room : RoomManager.rooms) {
                    if (room.getRoomNumber() == roomNumber) {
                        roomExists = true;
                        break;
                    }
                }
                if (roomExists) {
                    messageLabel.setTextFill(Color.RED);
                    messageLabel.setText("Room number already exists.");
                    return;
                }

                Room room = new Room(roomNumber, floor, roomType, false);

                RoomManager.rooms.add(room);

                //////////////////////////
                FileUtil.saveRooms(RoomManager.rooms, "C:\\demo6\\Rooms.dat");
                messageLabel.setTextFill(Color.GREEN);
                messageLabel.setText("Room added successfully.");
            } catch (NumberFormatException ex) {
                messageLabel.setTextFill(Color.RED);
                messageLabel.setText("Invalid input. Please enter valid data.");
            }
        });

        Button b2 = new Button("Back");
        b2.setStyle(buttonStyle);
        b2.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage3.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        GridPane layout = new GridPane();
        layout.add(l1, 0, 0);
        layout.add(l2,0,2);
        layout.add(t1, 1, 2);
        layout.add(l3, 0, 3);
        layout.add(comboBox, 1, 3);
        layout.add(l4, 0, 4);
        layout.add(cb1, 1, 4);
        layout.add(cb2, 2, 4);
        layout.add(b1, 1, 8);
        layout.add(b2, 2, 8);
        layout.add(messageLabel, 1, 9, 6, 1);
        layout.setVgap(5);
        layout.setHgap(5);
        layout.setAlignment(Pos.CENTER_LEFT);
        Rectangle rectangle = new Rectangle(460, 400, Color.LIGHTBLUE);
        rectangle.setStroke(Color.BLACK);
        rectangle.setStrokeWidth(2);
        StackPane pane = new StackPane(imageView,imageView1, rectangle, layout, Label);
        StackPane.setAlignment(rectangle, Pos.CENTER_LEFT);
        StackPane.setAlignment(Label, Pos.TOP_CENTER);
        StackPane.setAlignment(imageView1,Pos.CENTER_RIGHT);
        Scene scene3 = new Scene(pane, 1200, 600);
        stage3.setTitle("Add Room");
        //stage3.setResizable(false);
        stage3.setScene(scene3);
        stage3.show();
    }


}