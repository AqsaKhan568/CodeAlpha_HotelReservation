package org.example.demo6;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ShowRoom extends Application {

    private ObservableList<Room> roomData = FXCollections.observableArrayList();

    @Override
    public void start(Stage stage) {

        // Load rooms from RoomManager
        roomData.addAll(RoomManager.rooms);

        TableView<Room> table = new TableView<>(roomData);
        table.setMinWidth(500);
        table.setMinHeight(500);

        TableColumn<Room, Integer> roomNumCol = new TableColumn<>("Room Number");
        roomNumCol.setMinWidth(80);
        roomNumCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));

        TableColumn<Room, Integer> floorCol = new TableColumn<>("Floor");
        floorCol.setMinWidth(80);
        floorCol.setCellValueFactory(new PropertyValueFactory<>("floor"));

        TableColumn<Room, String> roomTypeCol = new TableColumn<>("Room Type");
        roomTypeCol.setMinWidth(80);
        roomTypeCol.setCellValueFactory(new PropertyValueFactory<>("roomType"));

        TableColumn<Room, Boolean> statusCol = new TableColumn<>("Status");
        statusCol.setMinWidth(80);
        statusCol.setCellValueFactory(new PropertyValueFactory<>("reserved"));

        table.getColumns().addAll(roomNumCol, floorCol, roomTypeCol, statusCol);


        Button backButton = new Button("Back");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        backButton.setStyle(buttonStyle);
        backButton.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox vBox = new VBox(10, table, backButton);
        vBox.setPrefWidth(500); // Ensure VBox width aligns with table width

        HBox hBox = new HBox(10,vBox);

        BorderPane root = new BorderPane();
        root.setCenter(hBox);

        Scene scene = new Scene(root, 1200, 600);
        stage.setTitle("Show Rooms");
        stage.setScene(scene);
        stage.show();
    }

}
