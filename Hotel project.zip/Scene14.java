package org.example.demo6;
import javafx.application.Application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.util.ArrayList;

public class Scene14 extends Application {

    private ObservableList<Reservation> reservationData = FXCollections.observableArrayList();

    @Override
    public void start(Stage stage){

        ArrayList<Reservation> reservations = FileUtil.loadReservations("C:\\demo6\\reservations.dat");
        reservationData.addAll(reservations);
        TableView<Reservation> table = new TableView<>(reservationData);
        table.setMinWidth(700);
        table.setMinHeight(500);

        TableColumn<Reservation, Integer> customerIDCol = new TableColumn<>("Customer ID");
        customerIDCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            Guest guest = reservation.getGuest();
            if (guest != null) {
                return new SimpleIntegerProperty(guest.getCustomerID()).asObject();
            } else {
                return new SimpleIntegerProperty().asObject(); // Or handle null case as needed
            }
        });
        customerIDCol.setMinWidth(80);

        TableColumn<Reservation, String> customerNameCol = new TableColumn<>("Customer Name");
        customerNameCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            Guest guest = reservation.getGuest();
            if (guest != null) {
                return new SimpleStringProperty(guest.getName());
            } else {
                return new SimpleStringProperty(); // Or handle null case as needed
            }
        });
        customerNameCol.setMinWidth(80);



        TableColumn<Reservation, String> reservationIDCol = new TableColumn<>("Reservation ID");
        reservationIDCol.setMinWidth(80);
        reservationIDCol.setCellValueFactory(new PropertyValueFactory<>("reservationID"));

        TableColumn<Reservation, Integer> roomNumberCol = new TableColumn<>("Room Number");
        roomNumberCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            Room room = reservation.getRoom();
            if (room != null) {
                return new SimpleIntegerProperty(room.getRoomNumber()).asObject();
            } else {
                return new SimpleIntegerProperty().asObject(); // Or handle null case as needed
            }
        });
        roomNumberCol.setMinWidth(80);


        TableColumn<Reservation, String> typeCol = new TableColumn<>("Room Type");
        typeCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            Room room = reservation.getRoom();
            if (room != null) {
                return new SimpleStringProperty(room.getRoomType());
            } else {
                return new SimpleStringProperty(); // Or handle null case as needed
            }
        });
        typeCol.setMinWidth(80);

        TableColumn<Reservation, LocalDate> checkInDateCol = new TableColumn<>("Check In date");
        checkInDateCol.setMinWidth(80);
        checkInDateCol.setCellValueFactory(new PropertyValueFactory<>("checkInDate"));

        TableColumn<Reservation, LocalDate> checkOutDateCol = new TableColumn<>("Check Out date");
        checkOutDateCol.setMinWidth(80);
        checkOutDateCol.setCellValueFactory(new PropertyValueFactory<>("CheckOutDate"));


        table.getColumns().addAll(customerIDCol,customerNameCol, reservationIDCol, roomNumberCol, typeCol, checkInDateCol, checkOutDateCol);
        Button backButton = new Button("Back");
        String buttonStyle = "-fx-font-family: 'Times New Roman'; -fx-font-size: 16px; -fx-font-weight: bold;";
        backButton.setStyle(buttonStyle);
        backButton.setOnAction(e -> {
            Scene2 scene2 = new Scene2();
            Stage stage2 = new Stage();
            try {
                scene2.start(stage2);
                stage.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox vBox = new VBox(10, table, backButton);
        vBox.setPrefWidth(500); // Ensure VBox width aligns with table width

        HBox hBox = new HBox(10,vBox);

        BorderPane root = new BorderPane();
        root.setCenter(hBox);

        Scene scene = new Scene(root, 1200, 600);
        stage.setTitle("Reservations");
        stage.setScene(scene);
        stage.show();

    }



}