package org.example.demo6;
import java.util.ArrayList;

public class RoomManager {
    public static ArrayList<Room> rooms = new ArrayList<>();

    static {
        rooms = FileUtil.loadRooms("C:\\demo6\\Rooms.dat");
    }

    public static void saveRooms() {
        FileUtil.saveRooms(rooms, "C:\\demo6\\Rooms.dat");
    }
}
