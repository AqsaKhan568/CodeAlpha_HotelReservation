package org.example.demo6;
import java.util.ArrayList;
import java.util.Scanner;

public class Hotel {
    private static ArrayList<Room> rooms;
    private static ArrayList<Guest> guests;
    private static ArrayList<Reservation> reservations;

    public static void main(String[] args) {
        String roomsFile = "C:\\demo6\\Room.dat";
        String guestsFile = "C:\\demo6\\guests.dat";
        String reservationsFile = "C:\\demo6\\reservations.dat";


        // Load existing rooms from file

        rooms = FileUtil.loadRooms(roomsFile);// Load Room objects

        ArrayList<Room> loadedRooms = FileUtil.loadRooms(roomsFile);
        if (loadedRooms.isEmpty()) {
            System.out.println("No rooms available.");
        } else {
            for (Room room : loadedRooms) {
                System.out.println(room); // This will call the overridden toString() method
            }
        }

        guests = FileUtil.loadGuests(guestsFile); // Load Guest objects
        reservations = FileUtil.loadReservations(reservationsFile); // Load Reservation objects


        if (rooms == null) {
            rooms = new ArrayList<>();
        }
        if (guests == null) {
            guests = new ArrayList<>();
        }
        if (reservations == null) {
            reservations = new ArrayList<>();
        }




        Scanner scanner = new Scanner(System.in);
        int i = 0;
        while (i != 10) {
            System.out.println("...................................");
            System.out.println("WELCOME TO HOTEL MANAGEMENT SYSTEM");
            System.out.println();
            System.out.println("Name : Hotel Transylvania");
            System.out.println("Email: transylvania123@gmail.com");
            System.out.println("Contact Number : 03100124675");
            System.out.println("....................................");
            System.out.println("1. Add Room.");
            System.out.println("2. Remove Room");
            System.out.println("3. Show All Rooms.");
            System.out.println("4. Add Guest.");
            System.out.println("5. Remove Guest.");
            System.out.println("6. Show all Guests.");
            System.out.println("7. Add Reservation.");
            System.out.println("8. Cancel Booking/Reservation.");
            System.out.println("9. Show All Reservations.");
            System.out.println("10. Quit.");

            i = scanner.nextInt();

            switch (i) {
                case 1:
                    Room.AddNewRoom(rooms);
                    FileUtil.saveRooms(rooms, roomsFile);
                    break;
                case 2:
                    Room.removeRoom(rooms);
                    FileUtil.saveRooms(rooms, roomsFile);
                    break;
                case 3:
                    Room.ShowAllRooms(rooms);
                    break;
                case 4:
                    Guest.AddNewGuest(guests);
                    FileUtil.saveGuests(guests, guestsFile);
                    break;
                case 5:
                    Guest.RemoveGuest(guests);
                    FileUtil.saveGuests(guests, guestsFile);
                    break;
                case 6:
                    Guest.ShowAllGuests(guests);
                    break;
                case 7:
                    Reservation.AddNewReservation(reservations, guests, rooms);
                    FileUtil.saveReservations(reservations, reservationsFile);
                    break;
                case 8:
                    Reservation.cancelBooking(reservations);
                    FileUtil.saveReservations(reservations, reservationsFile);

                    break;
                case 9:
                    Reservation.showAllReservations(reservations);
                    break;
                case 10:
                    System.out.println("Exiting the Program...");
                    FileUtil.saveRooms(rooms, roomsFile);
                    FileUtil.saveGuests(guests, guestsFile);
                    FileUtil.saveReservations(reservations, reservationsFile);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}

